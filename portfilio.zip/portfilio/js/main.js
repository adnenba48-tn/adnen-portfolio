/* ==========================================================================
   ADNEN BEN ABDALLAH PORTFOLIO — MAIN APPLICATION LOGIC
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initNavbarScroll();
  initMobileNav();
  initScrollReveal();
  initSkillFilters();
  initProjectModals();
  initCvModal();
  initContactForm();
  initVideoPlayback();
});

/* --------------------------------------------------------------------------
   1. Navbar Scroll Transition
   -------------------------------------------------------------------------- */
function initNavbarScroll() {
  const header = document.getElementById('main-header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  }, { passive: true });
}

/* --------------------------------------------------------------------------
   2. Mobile Navigation Drawer
   -------------------------------------------------------------------------- */
function initMobileNav() {
  const toggleBtn = document.getElementById('mobile-toggle-btn');
  const mobileNav = document.getElementById('mobile-nav');
  const mobileLinks = document.querySelectorAll('.mobile-nav .nav-link');

  if (!toggleBtn || !mobileNav) return;

  toggleBtn.addEventListener('click', () => {
    mobileNav.classList.toggle('active');
    const icon = toggleBtn.querySelector('i');
    if (icon) {
      icon.className = mobileNav.classList.contains('active') ? 'fas fa-times' : 'fas fa-bars';
    }
  });

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      mobileNav.classList.remove('active');
      const icon = toggleBtn.querySelector('i');
      if (icon) icon.className = 'fas fa-bars';
    });
  });
}

/* --------------------------------------------------------------------------
   3. Scroll Reveal Animations (IntersectionObserver)
   -------------------------------------------------------------------------- */
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal-up');
  
  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -80px 0px',
    threshold: 0.15
  };

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        obs.unobserve(entry.target);
      }
    });
  }, observerOptions);

  reveals.forEach(el => observer.observe(el));
}

/* --------------------------------------------------------------------------
   4. Skill Tabs Filter
   -------------------------------------------------------------------------- */
function initSkillFilters() {
  const tabs = document.querySelectorAll('.skill-tab');
  const cards = document.querySelectorAll('.skill-card');

  if (!tabs.length || !cards.length) return;

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const filter = tab.getAttribute('data-filter');

      cards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filter === 'all' || category === filter) {
          card.style.display = 'flex';
          card.style.opacity = '1';
        } else {
          card.style.display = 'none';
          card.style.opacity = '0';
        }
      });
    });
  });
}

/* --------------------------------------------------------------------------
   5. Case Study Modal System
   -------------------------------------------------------------------------- */
const projectDetailsData = {
  "smart-parking": {
    title: "Smart Parking System (LDR + Arduino)",
    category: "Hardware & IoT Systems",
    tech: ["Arduino Uno", "LDR (LM393)", "7-Segment Display", "Status LEDs", "Breadboard Wiring", "Digital Logic"],
    description: "Hardware IoT parking system using 4x LM393 LDR light sensors, an Arduino Uno controller, a Common Cathode 7-segment display counter, and status indicator LEDs.",
    details: [
      "Spot 1 to Spot 4 LDR Light Sensors connected to Arduino Digital pins D2 - D5.",
      "7-Segment Display (Common Cathode) driven via pins D6 - D12 displaying current available spaces (4 down to 0).",
      "Green Available LED on pin A0 (ON when spaces remain) & Red Full LED on pin A1 (ON when 0 spots left).",
      "Digital LDR Output Logic: Light (Free Spot) → DO = HIGH, Dark (Occupied Spot) → DO = LOW.",
      "Complete wiring schematic with 220Ω segment resistors and 10kΩ LDR module potentiometers."
    ],
    images: [
      { src: "assets/img/smart-parking-schematic.jpg", title: "Complete Hardware & Pin Diagram Schematic" },
      { src: "assets/img/smart-parking-sim1.jpg", title: "Tinkercad Simulation - 0 Available Spots (FULL)" },
      { src: "assets/img/smart-parking-sim2.jpg", title: "Tinkercad Simulation - 3 Available Spots" },
      { src: "assets/img/smart-parking-sim3.jpg", title: "Tinkercad Simulation - 1 Available Spot" },
      { src: "assets/img/smart-parking-sim4.jpg", title: "Tinkercad Simulation - 2 Available Spots" }
    ]
  },
  "smart-greenhouse": {
    title: "Smart Greenhouse System (Arduino + Digital Logic)",
    category: "IoT & Digital Logic Systems",
    tech: ["Arduino Uno", "LogicBench", "DHT22 Sensor", "Soil Moisture YL-69", "74HC Logic ICs", "LCD 16x2 I2C"],
    description: "Automated hybrid greenhouse climate control system combining Arduino Uno microcontroller with digital logic gates (74HC08, 74HC32, 74HC74, 74HC138) for automated pump, ventilation, lighting, and alarm control.",
    details: [
      "Hybrid architecture combining Arduino Uno with 74HC series digital logic ICs (AND, OR, NOT, Flip-Flops, Decoders).",
      "Multi-sensor environment monitoring: DHT22 (temp & humidity), Soil Moisture YL-69, LDR light sensor, MQ-2 gas sensor, DS3231 RTC.",
      "Real-time status display on LCD 16x2 I2C screen (Mode, Temp, Humidity, Alert messages).",
      "Automated relays and actuators driving irrigation pump, ventilation fan, grow lighting, and alert buzzer.",
      "Full simulation and test bench verification built in LogicBench."
    ],
    images: [
      { src: "assets/img/smart-greenhouse-schematic.jpg", title: "Smart Greenhouse Hybrid Schematic & LogicBench Guide" }
    ]
  },
  "forsa-tech": {
    title: "Forsa Tech Platform",
    category: "Web Application & Recruitment Hub",
    tech: ["HTML5", "CSS3", "JavaScript", "PHP", "MySQL", "UI/UX"],
    description: "The ultimate recruitment management web platform simplifying hiring processes, candidate tracking, interview schedules, and active job offer metrics for tech organizations.",
    details: [
      "Intuitive recruiter dashboard displaying total candidates, scheduled interviews, active offers, and hire stats.",
      "Candidate evolution analytics, status breakdown charts, and real-time recruitment pipeline tracking.",
      "Student & applicant portal for browsing engineering opportunities, internships, and developer roles.",
      "Sleek dark & light UI system with responsive layout and security authentication."
    ],
    images: [
      { src: "assets/img/forsa-tech-dashboard.jpg", title: "Forsa Tech Landing Page & Recruiter Dashboard Mockup" }
    ]
  },
  "sound-station": {
    title: "Sound & Audio Signal Station",
    category: "Multimedia & Sound Engineering",
    tech: ["Live Mixing Console", "Acoustics", "Audio Engineering", "DSP", "Signal Routing"],
    description: "Custom live sound engineering and audio mixing setup managed over 8+ years across live concert venues, acoustic tuning, and spatial audio events.",
    details: [
      "Over 8 years of professional live sound mixing, acoustic calibration, and frequency balancing.",
      "Multi-channel audio interface routing, snake cabling setup, and low-latency signal chains.",
      "Acoustic feedback suppression, EQ tuning, and dynamic range compression for live performers.",
      "Post-production mastering and spatial sound balancing."
    ],
    images: [
      { src: "assets/img/sound-station-live1.jpg", title: "Adnen at Live Sound Mixing Console" },
      { src: "assets/img/sound-station-live2.jpg", title: "Live Concert Mixing Board & Stage Performance" },
      { src: "assets/img/sound-station-live3.jpg", title: "Outdoor Venue Audio Console & Stage Setup" }
    ]
  }
};

function initProjectModals() {
  const modalOverlay = document.getElementById('project-modal');
  const modalClose = document.getElementById('modal-close-btn');
  const projectBtns = document.querySelectorAll('.project-modal-trigger');

  if (!modalOverlay || !modalClose) return;

  projectBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const id = btn.getAttribute('data-project-id');
      const data = projectDetailsData[id];

      if (data) {
        document.getElementById('modal-title').textContent = data.title;
        document.getElementById('modal-category').textContent = data.category;
        document.getElementById('modal-description').textContent = data.description;

        const techContainer = document.getElementById('modal-tech');
        techContainer.innerHTML = data.tech.map(t => `<span class="tech-pill">${t}</span>`).join('');

        const detailsContainer = document.getElementById('modal-details');
        detailsContainer.innerHTML = data.details.map(d => `<li><i class="fas fa-check-circle" style="color: var(--accent-red); margin-right: 8px;"></i> ${d}</li>`).join('');

        const galleryContainer = document.getElementById('modal-gallery-container');
        if (galleryContainer) {
          if (data.images && data.images.length > 0) {
            galleryContainer.innerHTML = `
              <h4 class="modal-gallery-heading">PROJECT PHOTOS & CIRCUIT SCHEMATICS (${data.images.length} IMAGES)</h4>
              <div class="modal-gallery-grid">
                ${data.images.map(img => `
                  <div class="modal-gallery-item" onclick="window.open('${img.src}', '_blank')">
                    <img src="${img.src}" alt="${img.title}" class="modal-gallery-img" title="${img.title}" />
                  </div>
                `).join('')}
              </div>
            `;
          } else {
            galleryContainer.innerHTML = '';
          }
        }

        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  modalClose.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) closeModal();
  });

  function closeModal() {
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

/* --------------------------------------------------------------------------
   6. CV Preview Modal
   -------------------------------------------------------------------------- */
function initCvModal() {
  const cvBtn = document.getElementById('btn-download-cv');
  const cvModal = document.getElementById('cv-modal');
  const cvClose = document.getElementById('cv-modal-close');

  if (!cvBtn || !cvModal || !cvClose) return;

  cvBtn.addEventListener('click', (e) => {
    e.preventDefault();
    cvModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  });

  cvClose.addEventListener('click', () => {
    cvModal.classList.remove('active');
    document.body.style.overflow = '';
  });

  cvModal.addEventListener('click', (e) => {
    if (e.target === cvModal) {
      cvModal.classList.remove('active');
      document.body.style.overflow = '';
    }
  });
}

/* --------------------------------------------------------------------------
   7. Contact Form Handler
   -------------------------------------------------------------------------- */
function initContactForm() {
  const form = document.getElementById('contact-form');
  const toast = document.getElementById('contact-toast');

  if (!form || !toast) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('form-name').value.trim();
    const email = document.getElementById('form-email').value.trim();
    const message = document.getElementById('form-message').value.trim();

    if (!name || !email || !message) {
      alert('Please fill out all required fields.');
      return;
    }

    toast.classList.add('success');
    form.reset();

    setTimeout(() => {
      toast.classList.remove('success');
    }, 5000);
  });
}

/* --------------------------------------------------------------------------
   8. Background Video Autoplay Protection
   -------------------------------------------------------------------------- */
function initVideoPlayback() {
  const video = document.getElementById('hero-video-player');
  if (!video) return;

  // Ensure video plays silently and reliably
  const playPromise = video.play();
  if (playPromise !== undefined) {
    playPromise.catch(error => {
      console.log('Video autoplay prevented by browser policy:', error);
    });
  }
}
