/* ==========================================================================
   ADNEN BEN ABDALLAH PORTFOLIO — I18N DICTIONARY (EN / FR)
   ========================================================================== */

const translations = {
  en: {
    // Navigation
    nav_home: "Home",
    nav_about: "About",
    nav_skills: "Skills",
    nav_projects: "Projects",
    nav_experience: "Experience",
    nav_creativity: "Tech × Creativity",
    nav_contact: "Contact",

    // Hero Section
    eyebrow: "ADNEN BEN ABDALLAH",
    hero_headline: "BUILD.<br/>CREATE.<br/>IMPACT.",
    hero_subtitle: "Computer Engineering & IoT Student • Creative Developer • Designer • Multimedia",
    btn_explore: "Explore My Work",
    btn_cv: "Download CV",
    scroll_text: "SCROLL",

    // About Section
    about_tag: "// EDITORIAL PROFILE",
    about_title: "ABOUT ME",
    about_p1: "I am a <strong>Computer Engineering & IoT student</strong> driven by technical innovation and creative expression. As <strong>President of The Code Bey – ISIMA</strong>, I lead developer initiatives, foster tech talent, and build smart embedded systems.",
    about_p2: "Combining <strong>8+ years in audio and sound engineering</strong> with modern software development and digital design, I create seamless digital and hardware experiences that connect systems, hardware, and human emotion.",
    
    // Stats
    stat1_num: "8+",
    stat1_title: "Years in Sound & Multimedia",
    stat1_desc: "Acoustics, live mixing, signal editing & audio production",

    stat2_num: "IoT",
    stat2_title: "Engineering & Embedded Focus",
    stat2_desc: "Arduino, STM32, VHDL, Sensors & Smart Automation",

    stat3_num: "Lead",
    stat3_title: "President — The Code Bey (ISIMA)",
    stat3_desc: "Directing student developer projects & technical workshops",

    // Skills Section
    skills_tag: "// TECHNICAL MATRIX",
    skills_title: "SKILLS & EXPERTISE",
    tab_all: "All Skills",
    tab_dev: "Development",
    tab_iot: "IoT & Embedded",
    tab_creative: "Creative",
    tab_tools: "Tools",

    // Projects Section
    projects_tag: "// CASE STUDIES",
    projects_title: "FEATURED PROJECTS",
    projects_desc: "Cinematic IoT engineering, web systems, and creative technology implementations.",
    btn_view_project: "View Case Study",

    // Projects Items
    proj1_title: "Smart Parking System (LDR + Arduino)",
    proj1_desc: "Hardware IoT parking solution built with Arduino Uno, 4x LM393 LDR light sensors, 7-segment display counter, and status indicator LEDs for real-time slot occupancy tracking.",
    
    proj2_title: "Smart Greenhouse System (Arduino + Logic)",
    proj2_desc: "Automated hybrid climate and precision irrigation control system combining Arduino Uno with digital logic ICs (74HC series), sensor arrays (DHT22, Soil Moisture YL-69, LDR, MQ-2), and LCD 16x2 display.",

    proj3_title: "Forsa Tech Platform",
    proj3_desc: "Web portal tailored for engineering students and technology enthusiasts to access innovation opportunities, workshops, and project showcases.",

    proj4_title: "The Code Bey Portal",
    proj4_desc: "Official web hub for the developer club at ISIMA, managing membership registrations, event schedules, hackathons, and tech learning tracks.",

    proj5_title: "Sound & Audio Signal Station",
    proj5_desc: "Custom audio workstation setup and signal processing layout for live venue mixing, spatial sound enhancement, and multi-track audio production.",

    proj6_title: "Creative Brand & Motion Systems",
    proj6_desc: "Comprehensive visual identity suites, user interface components, promotional visual assets, and motion graphics for technology organizations.",

    // Experience Section
    exp_tag: "// CAREER PATH",
    exp_title: "EXPERIENCE",
    
    role1_title: "President — The Code Bey – ISIMA",
    role1_desc: "Leading the official computer science and technology club at ISIMA. Directing technical projects, hosting hands-on workshops, organizing hackathons, and managing club strategy.",

    role2_title: "Senior Graphic Designer (Photoshop & Illustrator)",
    role2_desc: "Specialized senior graphic designer with advanced expertise in Adobe Photoshop and Adobe Illustrator. Creating high-end visual identities, vector artwork, complex digital compositions, UI/UX design components, and branding collateral.",

    role3_title: "Sound / Audio Technician",
    role3_desc: "8+ years managing audio engineering, acoustics configuration, live sound reinforcement, signal processing, and post-production mixing for major events and venue setups.",

    role4_title: "DevOps Club Graphic Designer",
    role4_desc: "Designing developer-focused visual branding assets, vector logos, UI elements, technical infographs, and event media using Adobe Illustrator and Photoshop.",

    // Creativity Section
    creative_tag: "// SYNERGY",
    creative_title: "TECH × CREATIVITY",
    creative_desc: "Visualizing the fusion of computer engineering, digital art, audio production, and visual branding.",

    // Contact Section
    contact_tag: "// GET IN TOUCH",
    contact_title: "LET'S BUILD SOMETHING.",
    contact_desc: "Whether you have a technical IoT project, web engineering inquiry, or creative multimedia collaboration, feel free to reach out.",
    
    label_name: "Your Name",
    label_email: "Email Address",
    label_subject: "Subject",
    label_message: "Message",
    placeholder_name: "e.g. Alex Morgan",
    placeholder_email: "alex@example.com",
    placeholder_subject: "Project Collaboration / Inquiry",
    placeholder_message: "Tell me about your project or idea...",
    btn_send: "Send Message",
    toast_success: "Thank you! Your message has been sent successfully.",

    // Footer
    footer_tagline: "Computer Engineering • IoT • Creative Technology",
    rights: "All Rights Reserved."
  },

  fr: {
    // Navigation
    nav_home: "Accueil",
    nav_about: "À Propos",
    nav_skills: "Compétences",
    nav_projects: "Projets",
    nav_experience: "Expérience",
    nav_creativity: "Tech × Créativité",
    nav_contact: "Contact",

    // Hero Section
    eyebrow: "ADNEN BEN ABDALLAH",
    hero_headline: "CONSTRUIRE.<br/>CRÉER.<br/>IMPACTER.",
    hero_subtitle: "Étudiant en Génie Informatique & IoT • Développeur Créatif • Designer • Multimédia",
    btn_explore: "Découvrir mes projets",
    btn_cv: "Télécharger CV",
    scroll_text: "DÉFILER",

    // About Section
    about_tag: "// PROFIL ÉDITORIAL",
    about_title: "À PROPOS DE MOI",
    about_p1: "Je suis un <strong>étudiant en Génie Informatique & IoT</strong> passionné par l'innovation technique et la création numérique. En tant que <strong>Président du club The Code Bey – ISIMA</strong>, je dirige des initiatives de développement et conçois des systèmes embarqués intelligents.",
    about_p2: "Associant <strong>8+ ans d'expérience en ingénierie sonore et multimédia</strong> au développement logiciel moderne et au design graphique, je conçois des solutions digitales et matérielles immersives à fort impact.",

    // Stats
    stat1_num: "8+",
    stat1_title: "Ans en Son & Multimédia",
    stat1_desc: "Acoustique, mixage live, édition de signal & production audio",

    stat2_num: "IoT",
    stat2_title: "Génie Informatique & Embarqué",
    stat2_desc: "Arduino, STM32, VHDL, Capteurs & Automatisation",

    stat3_num: "Président",
    stat3_title: "The Code Bey (ISIMA)",
    stat3_desc: "Direction des projets étudiants & ateliers techniques",

    // Skills Section
    skills_tag: "// MATRICE TECHNIQUE",
    skills_title: "COMPÉTENCES & EXPERTISE",
    tab_all: "Toutes",
    tab_dev: "Développement",
    tab_iot: "IoT & Embarqué",
    tab_creative: "Créatif",
    tab_tools: "Outils",

    // Projects Section
    projects_tag: "// ÉTUDES DE CAS",
    projects_title: "PROJETS EN VEDETTE",
    projects_desc: "Réalisations cinématiques en IoT, développement web et technologies créatives.",
    btn_view_project: "Voir l'étude de cas",

    // Projects Items
    proj1_title: "Système de Parking Intelligent (LDR + Arduino)",
    proj1_desc: "Solution matérielle IoT construite avec Arduino Uno, 4 capteurs de lumière LDR (LM393), afficheur 7-segments et LED d'état pour la gestion des places en temps réel.",

    proj2_title: "Système de Serre Intelligente (Arduino + Logique)",
    proj2_desc: "Système hybride automatisé de contrôle climatique et d'irrigation combinant Arduino Uno, circuits logiques 74HC, capteurs (DHT22, Humidité sol, LDR, MQ-2) et écran LCD 16x2.",

    proj3_title: "Plateforme Forsa Tech",
    proj3_desc: "Portail web destiné aux étudiants en ingénierie pour accéder aux opportunités d'innovation et ateliers technologiques.",

    proj4_title: "Portail The Code Bey",
    proj4_desc: "Hub web officiel du club de développement de l'ISIMA pour la gestion des membres, événements et ateliers.",

    proj5_title: "Station de Signal Audio",
    proj5_desc: "Configuration de station audio sur mesure et traitement du signal pour le mixage live et la production sonorisation.",

    proj6_title: "Systèmes de Marque & Design Visual",
    proj6_desc: "Suites d'identité visuelle, interfaces utilisateurs et animations graphiques pour organisations technologiques.",

    // Experience Section
    exp_tag: "// PARCOURS",
    exp_title: "EXPÉRIENCE",

    role1_title: "Président — The Code Bey – ISIMA",
    role1_desc: "Direction du club d'informatique à l'ISIMA. Organisation d'ateliers techniques, hackathons et projets de développement.",

    role2_title: "Senior Graphic Designer (Photoshop & Illustrator)",
    role2_desc: "Designer graphique senior spécialisé avec une expertise avancée sur Adobe Photoshop et Adobe Illustrator. Création d'identités visuelles haut de gamme, d'illustrations vectorielles, de retouches photo complexes et de composants UI/UX.",

    role3_title: "Technicien Son / Audio",
    role3_desc: "8+ ans de gestion de sonorisation, configuration acoustique, mixage en direct et post-production audio.",

    role4_title: "Graphiste Club DevOps",
    role4_desc: "Conception d'actifs visuels axés développeurs, logos vectoriels, éléments UI et supports médiatiques avec Adobe Illustrator et Photoshop.",

    // Creativity Section
    creative_tag: "// SYNERGIE",
    creative_title: "TECH × CRÉATIVITÉ",
    creative_desc: "La convergence entre génie informatique, art numérique, ingénierie sonore et design visuel.",

    // Contact Section
    contact_tag: "// CONTACT",
    contact_title: "CONSTRUISONS ENSEMBLE.",
    contact_desc: "Que ce soit pour un projet IoT, du développement web ou une collaboration multimédia, n'hésitez pas à me contacter.",

    label_name: "Votre Nom",
    label_email: "Adresse Email",
    label_subject: "Sujet",
    label_message: "Message",
    placeholder_name: "ex. Alex Morgan",
    placeholder_email: "alex@example.com",
    placeholder_subject: "Collaboration / Demande de projet",
    placeholder_message: "Parlez-moi de votre projet...",
    btn_send: "Envoyer le message",
    toast_success: "Merci ! Votre message a été envoyé avec succès.",

    // Footer
    footer_tagline: "Génie Informatique • IoT • Technologies Créatives",
    rights: "Tous droits réservés."
  }
};

let currentLang = 'en';

function setLanguage(lang) {
  if (!translations[lang]) return;
  currentLang = lang;
  document.documentElement.lang = lang;
  
  const elements = document.querySelectorAll('[data-i18n]');
  elements.forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = translations[lang][key];
      } else {
        el.innerHTML = translations[lang][key];
      }
    }
  });

  // Update button active states
  const btnEn = document.getElementById('btn-lang-en');
  const btnFr = document.getElementById('btn-lang-fr');
  if (btnEn && btnFr) {
    if (lang === 'en') {
      btnEn.classList.add('active');
      btnFr.classList.remove('active');
    } else {
      btnFr.classList.add('active');
      btnEn.classList.remove('active');
    }
  }

  localStorage.setItem('adnen_lang', lang);
}

function initI18n() {
  const savedLang = localStorage.getItem('adnen_lang') || 'en';
  setLanguage(savedLang);

  const btnEn = document.getElementById('btn-lang-en');
  const btnFr = document.getElementById('btn-lang-fr');
  if (btnEn) btnEn.addEventListener('click', () => setLanguage('en'));
  if (btnFr) btnFr.addEventListener('click', () => setLanguage('fr'));
}

document.addEventListener('DOMContentLoaded', initI18n);
